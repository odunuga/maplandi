<?php

return [
    'name' => 'Cart'
];
