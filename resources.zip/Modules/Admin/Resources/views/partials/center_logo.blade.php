<div class="text-center m-t-0 m-b-15">
    <a href="{{url('/')}}" class="logo logo-admin">
        <img src="{{ asset('vendor/admin/images/logo1.png') }}" alt="" height="100"></a>
</div>
