<x-app-layout>
    @livewire('show-product',['product_id'=>$product->id])
</x-app-layout>
