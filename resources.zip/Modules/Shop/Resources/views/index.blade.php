<x-app-layout>
  <livewire:shop-products/>
</x-app-layout>
