<?php


namespace Modules\Shop\Repository;


use App\Repository\CoreInterface;

interface ShopInterface extends CoreInterface
{


}
