require('./bootstrap');
require('datatables.net-bs4');
require('datatables.net-buttons-bs4');

import Alpine from 'alpinejs';

window.Alpine = Alpine;

Alpine.start();
