<?php
return [
    'information' => 'Information',
    'description' => 'Description',
    'tags' => 'Tags',
    'no-comments' => 'No Comments',
    'comments' => 'Comments',
    'post-a-comment'=>'Post a comment',


];
