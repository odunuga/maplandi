<?php


return [
    'home' => 'Home',
    'shop' => 'Shop',
    'cart' => 'Cart',
    'login_to_buy' => 'Login to Buy',
    'login' => 'Login',
    'register' => 'Register',
    'profile' => 'Profile',
    'logout' => 'Logout',
    'account' => 'Account',
    'orders' => 'Orders',
    'saved_items' => 'Saved Items'
];








