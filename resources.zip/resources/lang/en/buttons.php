<?php

return
    [
        'update' => 'Update',
        'back' => 'Back',
        'go-back' => 'Go Back',
        'login'=>'Log In',
        'forgot'=>'Forgot your password?'
    ];
