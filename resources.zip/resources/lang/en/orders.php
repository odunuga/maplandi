<?php

return [
    'title' => 'Orders Record',
    'single_order' => [
        'title' => 'Order '
    ]
];
