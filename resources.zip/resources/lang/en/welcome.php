<?php

return [
  'first_password'=>[
      'message'=>'Set Your Password'
  ]
];
