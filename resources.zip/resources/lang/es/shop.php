<?php
return [
    'information' => 'información',
    'description' => 'descripción',
    'tags' => 'Etiquetas',
    'no-comment' => 'No hay comentarios',
    'comments' => 'Comentarios',
    'post-a-comment'=>'Publicar un comentario',


];
