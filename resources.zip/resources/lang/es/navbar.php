<?php


return [
    'home' => 'hogar',
    'shop' => 'tienda',
    'cart' => 'carro',
    'login_to_buy' => 'Iniciar sesión para comprar',
    'login' => 'Iniciar sesión',
    'register' => 'registro',
    'profile' => 'perfil',
    'logout' => 'Cerrar sesión',
    'account' => 'cuenta',
    'orders' => 'Órdenes',
    'saved_items' => 'Elementos guardados'
];








