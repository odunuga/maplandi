<?php

return [
    'title' => 'Información de pedidos',
    'single_order' => [
        'title' => 'Órdenes '
    ]
];
