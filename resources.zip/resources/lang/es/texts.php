<?php
return [
    'new_password' => 'Nueva contraseña',
    'new_password_placeholder' => 'Introduzca una nueva contraseña',
    'confirm_password' => 'Confirmar contraseña',
    'confirm_password_placeholder' => 'Confirme su contraseña',
    'shipping_address' => 'Dirección de envío',
    'upload_success' => 'Imagen cargada correctamente',
    'upload_failed' => 'No se pudo cargar la imagen',
    'product_loaded_success' => ' Producto agregado correctamente',
    'product_update_success' => 'El producto se actualizó correctamente',
    'add_icon' => 'Agregar icono',
    'welcome_title' => 'Bienvenido a ',
    'categories'=>'Categorías',
    'search'=>'buscar'
];
