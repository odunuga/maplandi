<?php

return
    [
        'update' => 'actualizar',
        'back' => 'Atrás',
        'go-back' => 'Volver',
        'login'=>'Inicia sesión',
        'forgot'=>'Olvidó su contraseña?'
    ];
