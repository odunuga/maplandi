<?php

return [
  'first_password'=>[
      'message'=>'Establezca su contraseña'
  ]
];
