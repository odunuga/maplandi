<a id="filteredLike{{$product->id}}" href="javascript:void(0)" class="{{ $liked }}"  wire:click="setLike"><i class="{{ $like_icon }} "></i></a>
