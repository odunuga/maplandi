<div class="container">
    <div class="wrapper wrapper-content animated fadeInRight">
        @livewire('checkout-details')
    </div>
</div>
