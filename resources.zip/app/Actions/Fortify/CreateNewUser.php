<?php

namespace App\Actions\Fortify;

use App\Models\User;
use App\Notifications\NewRegistration;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Laravel\Fortify\Contracts\CreatesNewUsers;
use Laravel\Jetstream\Jetstream;
use Modules\Cart\Entities\ShippingAddress;

class CreateNewUser implements CreatesNewUsers
{
    use PasswordValidationRules;

    /**
     * Validate and create a newly registered user.
     *
     * @param array $input
     * @return \App\Models\User
     */
    public function create(array $input)
    {
        Validator::make($input, [
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'password' => $this->passwordRules(),
            'phone' => ['required', 'min:7'],
            'terms' => Jetstream::hasTermsAndPrivacyPolicyFeature() ? ['required', 'accepted'] : '',
        ])->validate();

        $user = User::create([
            'name' => $input['name'],
            'email' => $input['email'],
            'password' => Hash::make($input['password']),
        ]);
        $name = explode(" ", $user->name);
        ShippingAddress::create([
            'user_id' => $user->id,
            'first_name' => isset($name[0]) ? $name[0] : '',
            'last_name' => isset($name[1]) ? $name[1] : '',
            'email' => $user->email,
            'phone' => $input['phone'],
            'address' => ''
        ]);

        $user->notify(new NewRegistration($user));
        return $user;
    }
}
